JARVIS Local Assistant Version 1.0.0
Platform: macos
Run 'python jarvis_local_setup.py' to initialize.