JARVIS Local Assistant Version 1.0.0
Platform: linux
Run 'python jarvis_local_setup.py' to initialize.