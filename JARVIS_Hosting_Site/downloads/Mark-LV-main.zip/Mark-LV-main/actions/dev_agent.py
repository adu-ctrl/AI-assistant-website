import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path, PurePosixPath, PureWindowsPath


def get_base_dir():
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent.parent


BASE_DIR         = get_base_dir()
API_CONFIG_PATH  = BASE_DIR / "config" / "api_keys.json"
PROJECTS_DIR     = Path.home() / "Desktop" / "JarvisProjects"
MAX_FIX_ATTEMPTS = 5
MODEL_TIMEOUT_MS = 180_000
_WEB_REQUEST = re.compile(
    r"\b(?:website|web site|web app|web application|landing page|portfolio site)\b",
    re.IGNORECASE,
)
# Model choice, timeout and fallback ladder all live in core/gemini.py.
from core import gemini

MODEL_PLANNER    = gemini.SMART
MODEL_WRITER     = gemini.SMART


def _console_log(message: str) -> None:
    try:
        print(message)
    except UnicodeEncodeError:
        encoding = getattr(sys.stdout, "encoding", None) or "ascii"
        print(message.encode(encoding, errors="replace").decode(encoding))


def _get_api_key() -> str:
    with open(API_CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)["gemini_api_key"]


def _get_model(model_name: str = gemini.SMART):
    """Planning and writing whole files — the reasoning tier, and a long
    deadline because the answer is a source file rather than a sentence."""
    class _W:
        def generate_content(self, contents):
            resp = gemini.call(contents, tier=model_name,
                               timeout_ms=MODEL_TIMEOUT_MS)
            if resp is None:
                raise RuntimeError("every Gemini model on the ladder failed")
            return resp

    return _W()


def _strip_fences(text: str) -> str:
    text = text.strip()
    text = re.sub(r"^```[a-zA-Z]*\r?\n?", "", text)
    text = re.sub(r"\r?\n?```\s*$", "", text)
    return text.strip()


def _is_rate_limit(error: Exception) -> bool:
    msg = str(error).lower()
    return "429" in msg or "quota" in msg or "resource_exhausted" in msg


def _parse_traceback(output: str, project_files: list[str]) -> tuple[str | None, int | None]:

    pattern = re.compile(r'File ["\']([^"\']+\.py)["\'],\s+line\s+(\d+)', re.IGNORECASE)
    matches = pattern.findall(output)

    for raw_path, line_str in reversed(matches):
        raw_name = Path(raw_path).name
        for pf in project_files:
            if Path(pf).name == raw_name or pf == raw_path or raw_path.endswith(pf):
                return pf, int(line_str)

    return None, None


def _classify_error(output: str) -> str:

    low = output.lower()

    if "command not found:" in low or "run error:" in low:
        return "runtime_error"

    if any(x in low for x in ("no module named", "modulenotfounderror", "importerror")):
        return "dependency_error"

    if "syntaxerror" in low or "invalid syntax" in low:
        return "syntax_error"
    
    if "cannot import" in low or "importerror" in low:
        return "import_error"

    if any(x in low for x in (
        "traceback", "exception", "error:", "nameerror", "typeerror",
        "attributeerror", "valueerror", "keyerror", "indexerror",
        "zerodivisionerror", "filenotfounderror", "permissionerror",
    )):
        return "runtime_error"

    return "none"


def _has_error(output: str, run_command: str) -> bool:
    
    low = output.lower()

    if "long-running app" in low:
        return False
    if "timed out" in low:
        return True

    if not output.strip():
        return False

    exit_code = re.search(r"\[DEVAGENT_EXIT_CODE=(-?\d+)\]", output)
    if exit_code:
        return int(exit_code.group(1)) != 0

    error_type = _classify_error(output)
    return error_type != "none"

class RateLimitError(Exception):
    pass


def _normalise_project_path(file_path: str) -> str:
    raw = str(file_path or "").strip().replace("\\", "/")
    windows_path = PureWindowsPath(raw)
    parts = raw.split("/")
    if (not raw or raw.startswith("/") or PurePosixPath(raw).is_absolute()
            or windows_path.is_absolute() or windows_path.drive
            or ":" in raw or any(part.rstrip(" .") in ("", ".", "..") for part in parts)
            or all(part in ("", ".") for part in parts)):
        raise ValueError(f"Project file path must stay inside the project: {file_path!r}")
    return str(PurePosixPath(raw))


def _safe_project_path(project_dir: Path, file_path: str) -> Path:
    relative = _normalise_project_path(file_path)
    root = project_dir.resolve()
    target = (root / relative).resolve()
    try:
        target.relative_to(root)
    except ValueError as e:
        raise ValueError(f"Project file path escapes the project directory: {file_path!r}") from e
    return target


def _validate_project_plan(plan: dict) -> dict:
    if not isinstance(plan, dict):
        raise ValueError("Planner response must be a JSON object.")
    files = plan.get("files")
    if not isinstance(files, list) or not files:
        raise ValueError("Planner response must contain at least one project file.")

    paths = set()
    for file_info in files:
        if not isinstance(file_info, dict):
            raise ValueError("Planner returned a malformed file entry.")
        file_path = _normalise_project_path(file_info.get("path", ""))
        if file_path in paths:
            raise ValueError(f"Planner returned duplicate project path: {file_path}")
        paths.add(file_path)
        file_info["path"] = file_path
        imports = file_info.get("imports", [])
        if not isinstance(imports, list) or not all(isinstance(item, str) for item in imports):
            raise ValueError(f"Planner returned invalid imports for {file_path}.")

    entry_point = _normalise_project_path(plan.get("entry_point", ""))
    if entry_point not in paths:
        raise ValueError(f"Planner entry point is missing from its file list: {entry_point}")
    plan["entry_point"] = entry_point
    dependencies = plan.get("dependencies", [])
    if not isinstance(dependencies, list) or not all(
            isinstance(item, str) and item.strip() for item in dependencies):
        raise ValueError("Planner returned an invalid dependencies list.")
    return plan


def _plan_project(description: str, language: str) -> dict:
    model = _get_model(MODEL_PLANNER)
    website_rules = ""
    if _WEB_REQUEST.search(description):
        website_rules = """
Website-specific requirements:
1. Build a complete, polished, responsive website—not a code snippet or wireframe.
2. Plan an actual index.html plus the CSS and JavaScript files it loads; include every
   required page, interaction and local asset in the file list.
3. Use semantic HTML, keyboard-accessible controls, responsive layouts, and a
   cohesive visual system with deliberate typography, spacing, color and hover/focus states.
4. Implement every requested interaction end to end. Do not use placeholder links,
   lorem ipsum, TODOs, or controls that do nothing.
5. Prefer a self-contained HTML/CSS/JavaScript implementation unless the request
   calls for a framework. If using Node tooling, define usable scripts in package.json;
   put Node packages in package.json, not the Python dependencies list.
6. Set the run command to a real production build/check when one is available.
"""

    prompt = f"""You are a senior software architect. Create a complete, practical file plan that fully delivers this project.

Language: {language}
Description: {description}
{website_rules}

Return ONLY valid JSON — no markdown, no explanation:
{{
  "project_name": "snake_case_name",
  "entry_point": "main.py",
  "files": [
    {{
      "path": "main.py",
      "description": "Entry point — what it does and which modules it imports",
      "imports": ["utils.helpers", "core.engine"]
    }},
    {{
      "path": "utils/helpers.py",
      "description": "Helper utilities — what functions it exposes",
      "imports": []
    }}
  ],
  "run_command": "python main.py",
  "dependencies": ["requests"]
}}

Critical rules:
1. List files in DEPENDENCY ORDER — files with no imports come first, entry point comes last.
2. The "imports" field must list every other project module this file imports (dot-notation, e.g. "utils.helpers").
3. Include all files needed to deliver the requested features; avoid both missing pieces and needless scaffolding.
4. Entry point must be in the files list.
5. Use relative paths only (e.g. "utils/helpers.py", not absolute paths).
6. Standard library modules (os, sys, json, etc.) do NOT go in "dependencies".

JSON:"""

    try:
        response = model.generate_content(prompt)
        raw = _strip_fences(response.text)
        return _validate_project_plan(json.loads(raw))
    except json.JSONDecodeError as e:
        raise ValueError(f"Planner returned invalid JSON: {e}\nRaw: {response.text[:300]}")
    except Exception as e:
        if _is_rate_limit(e):
            raise RateLimitError(str(e))
        raise

def _write_file(
    file_info: dict,
    project_description: str,
    all_files: list[dict],
    language: str,
    project_dir: Path,
    already_written: dict[str, str],
) -> str:
    model = _get_model(MODEL_WRITER)

    file_path = file_info["path"]
    file_desc = file_info.get("description", "")
    file_imports = file_info.get("imports", [])

    file_list = "\n".join(
        f"  [{i+1}] {f['path']}: {f.get('description', '')}"
        for i, f in enumerate(all_files)
    )

    dependency_context = ""
    for dep_dotted in file_imports:
        dep_path = dep_dotted.replace("\\", "/")
        if language.lower() == "python":
            candidates = [
                dep_path if dep_path.endswith(".py")
                else dep_path.replace(".", "/") + ".py"
            ]
        else:
            web_suffixes = (".js", ".jsx", ".ts", ".tsx", ".css", ".json")
            if dep_path.lower().endswith(web_suffixes):
                candidates = [dep_path]
            else:
                module_path = dep_path.replace(".", "/")
                candidates = [
                    module_path + suffix
                    for suffix in web_suffixes
                ]
                candidates.extend(
                    f"{module_path}/index{suffix}"
                    for suffix in (".js", ".jsx", ".ts", ".tsx")
                )
        matched_path = next((path for path in candidates if path in already_written), None)
        if matched_path:
            code_snippet = already_written[matched_path][:2000]
            dependency_context += (
                f"\n\n--- {matched_path} (you must import from this) ---\n{code_snippet}"
            )

    lang_rules = ""
    if language.lower() == "python":
        lang_rules = """
Python-specific rules:
- Use type hints for all function signatures.
- Add docstrings for all public functions and classes.
- Use if __name__ == "__main__": guard in the entry point.
- For relative imports within the project, use: from utils.helpers import foo  (match the project structure exactly).
- Do NOT use implicit relative imports (from . import ...) unless it's a proper package with __init__.py.
- If this is a package subdirectory, create __init__.py files where needed."""
    elif language.lower() in ("javascript", "typescript", "js", "ts"):
        lang_rules = """
JS/TS-specific rules:
- Use ES modules (import/export), not CommonJS (require).
- Add JSDoc comments for all exported functions.
- Handle promise rejections with try/catch in async functions."""
    web_rules = ""
    if _WEB_REQUEST.search(project_description):
        web_rules = """
Website implementation requirements:
- Treat the supplied project goal as a real product brief, not a demo. Deliver a
  cohesive, production-quality experience with intentional visual hierarchy.
- Make every page responsive from narrow mobile screens through desktop.
- Use semantic accessible markup, visible keyboard focus, useful labels and readable contrast.
- Implement all requested navigation, buttons, forms, filters and other interactions;
  do not leave fake links, dead controls, placeholder copy or TODOs.
- Match file references to the planned project structure exactly and make the entry
  point load the complete site without missing assets.
"""

    prompt = f"""You are a senior {language} developer writing production-quality code for a real project.

Project goal: {project_description}

Complete project file structure (in dependency order):
{file_list}

{f"Dependencies this file must import from other project files:{dependency_context}" if dependency_context else ""}

Your task: Write the complete, working code for: {file_path}
Purpose of this file: {file_desc}
{f"This file imports from: {', '.join(file_imports)}" if file_imports else "This file has no project-internal imports."}

{lang_rules}
{web_rules}

General rules:
- Output ONLY raw code. Absolutely no explanation, no markdown, no triple backticks.
- Write COMPLETE, RUNNABLE code — no placeholders, no "# TODO", no "pass" stubs.
- Every import must either be from the standard library, listed dependencies, or the project files shown above.
- Match import paths EXACTLY to the file paths in the project structure (e.g. if file is "utils/helpers.py", import as "from utils.helpers import ...").
- Use proper error handling (try/except) where I/O or network calls are made.
- The code must work correctly when the project entry point is run from the project root directory.

Code for {file_path}:"""

    try:
        response = model.generate_content(prompt)
        code = _strip_fences(response.text)

        full_path = _safe_project_path(project_dir, file_path)
        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_text(code, encoding="utf-8")

        _console_log(f"[DevAgent] ✅ Written: {file_path} ({len(code)} chars)")
        return code

    except Exception as e:
        if _is_rate_limit(e):
            raise RateLimitError(str(e))
        raise

def _install_dependencies(dependencies: list[str], project_dir: Path) -> str:
    results = []
    if dependencies:
        to_install = []
        for dep in dependencies:
            pkg_name = re.split(r"[>=<!]", dep)[0].strip()
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "show", pkg_name],
                    capture_output=True, text=True, timeout=20,
                )
            except subprocess.TimeoutExpired:
                result = None
            if result is None or result.returncode != 0:
                to_install.append(dep)
            else:
                _console_log(f"[DevAgent] ✓ Already installed: {pkg_name}")

        if to_install:
            _console_log(f"[DevAgent] 📦 Installing Python packages: {to_install}")
            try:
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "install"] + to_install,
                    capture_output=True, text=True,
                    encoding="utf-8", errors="replace",
                    timeout=600, cwd=str(project_dir)
                )
                results.append(
                    f"Installed Python dependencies: {', '.join(to_install)}"
                    if result.returncode == 0
                    else f"Python install warning (non-fatal): {result.stderr[:300]}"
                )
            except subprocess.TimeoutExpired:
                results.append("Python dependency install timed out (non-fatal).")
            except Exception as e:
                results.append(f"Python install error (non-fatal): {e}")
        else:
            results.append(f"All Python dependencies already installed: {', '.join(dependencies)}")

    if (project_dir / "package.json").is_file():
        npm = shutil.which("npm")
        if not npm:
            results.append("Node dependencies were not installed: npm is not available on PATH.")
        else:
            _console_log("[DevAgent] 📦 Installing Node packages with npm...")
            try:
                result = subprocess.run(
                    _npm_command(npm, ["install", "--no-audit", "--no-fund", "--progress=false"]),
                    capture_output=True, text=True, encoding="utf-8", errors="replace",
                    timeout=600, cwd=str(project_dir),
                )
                results.append(
                    "Node dependencies installed."
                    if result.returncode == 0
                    else f"npm install warning (non-fatal): {result.stderr[-500:]}"
                )
            except subprocess.TimeoutExpired:
                results.append("Node dependency install timed out after 600 seconds.")
            except Exception as e:
                results.append(f"npm install error: {e}")

    return "\n".join(results) if results else "No external dependencies."


def _npm_command(npm: str, args: list[str]) -> list[str]:
    command = [npm, *args]
    if os.name == "nt":
        return [os.environ.get("COMSPEC", "cmd.exe"), "/d", "/c", *command]
    return command


def _open_vscode(project_dir: Path) -> bool:
    vscode_candidates = [
        "code",
        rf"C:\Users\{Path.home().name}\AppData\Local\Programs\Microsoft VS Code\bin\code.cmd",
        r"C:\Program Files\Microsoft VS Code\bin\code.cmd",
    ]
    for cmd in vscode_candidates:
        try:
            subprocess.Popen(
                [cmd, str(project_dir)],
                shell=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            time.sleep(1.5)
            _console_log(f"[DevAgent] 💻 VSCode opened: {project_dir}")
            return True
        except Exception:
            continue
    return False

def _run_project(run_command: str, project_dir: Path, timeout: int = 30) -> str:
    _console_log(f"[DevAgent] 🚀 Running: {run_command}")
    try:
        parts = run_command.split()
        if parts[0].lower() == "python":
            parts[0] = sys.executable
        elif parts[0].lower() == "npm":
            npm = shutil.which("npm")
            if not npm:
                return "Command not found: npm"
            parts = _npm_command(npm, parts[1:])

        result = subprocess.run(
            parts,
            capture_output=True, text=True,
            encoding="utf-8", errors="replace",
            timeout=timeout,
            cwd=str(project_dir)
        )

        stdout = result.stdout.strip()
        stderr = result.stderr.strip()

        combined_parts = []
        if stdout:
            combined_parts.append(f"STDOUT:\n{stdout}")
        if stderr:
            combined_parts.append(f"STDERR:\n{stderr}")

        combined_parts.append(f"[DEVAGENT_EXIT_CODE={result.returncode}]")
        return "\n\n".join(combined_parts) if combined_parts else (
            f"Ran with no output.\n[DEVAGENT_EXIT_CODE={result.returncode}]"
        )

    except subprocess.TimeoutExpired:
        if re.search(r"\bnpm\s+run\s+(?:build|test|check|lint)\b", run_command, re.I):
            return f"Build/check timed out after {timeout}s."
        return f"Timed out after {timeout}s — long-running app (server/GUI) is likely working."
    except FileNotFoundError as e:
        return f"Command not found: {e}"
    except Exception as e:
        return f"Run error: {e}"

def _try_auto_install(error_output: str, project_dir: Path) -> bool:
    """If there is a ModuleNotFoundError, tries to auto-install the missing package."""
    pattern = re.compile(
        r"No module named ['\"]([a-zA-Z0-9_\-\.]+)['\"]", re.IGNORECASE
    )
    match = pattern.search(error_output)
    if not match:
        return False

    pkg = match.group(1).replace("_", "-").split(".")[0]
    _console_log(f"[DevAgent] 🔧 Auto-installing missing package: {pkg}")
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", pkg],
            capture_output=True, text=True,
            encoding="utf-8", errors="replace",
            timeout=60, cwd=str(project_dir)
        )
        return result.returncode == 0
    except Exception:
        return False

def _fix_files(
    error_output: str,
    project_description: str,
    all_files: list[dict],
    file_codes: dict[str, str],
    language: str,
    project_dir: Path,
    entry_point: str,
) -> dict[str, str]:

    model = _get_model(MODEL_PLANNER)

    error_file, error_line = _parse_traceback(error_output, list(file_codes.keys()))
    error_type = _classify_error(error_output)

    files_to_fix: list[str] = []

    if error_file:
        files_to_fix.append(error_file)
        if error_type == "import_error":
            for fi in all_files:
                if error_file.replace("/", ".").replace(".py", "") in fi.get("imports", []):
                    p = fi["path"]
                    if p not in files_to_fix:
                        files_to_fix.append(p)
    else:
        files_to_fix.append(entry_point)

    updated_codes: dict[str, str] = {}

    for fix_path in files_to_fix:
        current_code = file_codes.get(fix_path, "")

        other_ctx = ""
        for fp, code in file_codes.items():
            if fp != fix_path and code:
                snippet = code[:1500] + ("..." if len(code) > 1500 else "")
                other_ctx += f"\n--- {fp} ---\n{snippet}\n"

        line_hint = f"\nError appears to be near line {error_line} in this file." if (
            error_line and fix_path == error_file
        ) else ""

        prompt = f"""You are an expert {language} debugger. Fix the broken file below.

Project goal: {project_description}

All project files:
{chr(10).join(f"  - {f['path']}: {f.get('description', '')}" for f in all_files)}

Other files for context (read-only — fix only the target file):
{other_ctx[:3500]}

File to fix: {fix_path}{line_hint}
Error type: {error_type}

Error output:
{error_output[:2500]}

Current (broken) code:
{current_code}

Rules:
- Output ONLY the complete fixed code. No explanation, no markdown, no backticks.
- Fix ALL errors visible in the error output.
- Keep all existing correct logic — do not remove working features.
- Ensure import paths match the actual project file structure exactly.
- Do NOT introduce new bugs or remove error handling.

Fixed code for {fix_path}:"""

        try:
            response = model.generate_content(prompt)
            fixed = _strip_fences(response.text)

            full_path = _safe_project_path(project_dir, fix_path)
            full_path.parent.mkdir(parents=True, exist_ok=True)
            full_path.write_text(fixed, encoding="utf-8")

            updated_codes[fix_path] = fixed
            _console_log(f"[DevAgent] 🔧 Fixed: {fix_path}")

        except Exception as e:
            if _is_rate_limit(e):
                raise RateLimitError(str(e))
            _console_log(f"[DevAgent] ⚠️ Could not fix {fix_path}: {e}")

    return updated_codes

def _build_project(
    description: str,
    language: str,
    project_name: str,
    timeout: int,
    speak=None,
    player=None,
) -> str:

    def log(msg: str):
        _console_log(f"[DevAgent] {msg}")
        if player:
            player.write_log(f"[DevAgent] {msg}")

    log("Planning project structure...")
    try:
        plan = _plan_project(description, language)
    except RateLimitError:
        msg = "Rate limit reached, sir. Please try again in a moment."
        if speak: speak(msg)
        return msg
    except ValueError as e:
        msg = f"Planning failed: {e}"
        if speak: speak(msg)
        return msg

    proj_name    = project_name or plan.get("project_name", "jarvis_project")
    proj_name    = re.sub(r"[^\w\-]", "_", proj_name)
    project_dir  = PROJECTS_DIR / proj_name
    project_dir.mkdir(parents=True, exist_ok=True)

    files        = plan.get("files", [])
    entry_point  = plan.get("entry_point", "main.py")
    run_command  = plan.get("run_command", f"python {entry_point}")
    dependencies = plan.get("dependencies", [])

    log(f"Project: {proj_name} | Files: {len(files)} | Entry: {entry_point}")

    sorted_files = files

    file_codes: dict[str, str] = {}

    for file_info in sorted_files:
        file_path = file_info.get("path", "")
        if not file_path:
            continue

        log(f"Writing {file_path}...")
        for attempt in range(2):
            try:
                code = _write_file(
                    file_info=file_info,
                    project_description=description,
                    all_files=files,
                    language=language,
                    project_dir=project_dir,
                    already_written=file_codes,
                )
                file_codes[file_path] = code
                time.sleep(0.4)
                break
            except RateLimitError:
                if attempt == 0:
                    log("Rate limit — waiting 20s...")
                    time.sleep(20)
                else:
                    log(f"Rate limit retry failed for {file_path}, skipping.")
            except Exception as e:
                log(f"Failed to write {file_path}: {e}")
                break

    if not file_codes:
        msg = "I could not write any project files, sir."
        if speak: speak(msg)
        return msg

    if dependencies or (project_dir / "package.json").is_file():
        install_result = _install_dependencies(dependencies, project_dir)
        log(install_result)

    _open_vscode(project_dir)

    last_output   = ""
    auto_installs = 0  

    for attempt in range(1, MAX_FIX_ATTEMPTS + 1):
        log(f"Running project (attempt {attempt}/{MAX_FIX_ATTEMPTS})...")
        run_timeout = max(timeout, 120) if (project_dir / "package.json").is_file() else timeout
        last_output = _run_project(run_command, project_dir, run_timeout)
        log(f"Output preview: {last_output[:150]}")

        if not _has_error(last_output, run_command):
            msg = (
                f"Project '{proj_name}' is working, sir. "
                f"Built in {attempt} attempt{'s' if attempt > 1 else ''}. "
                f"Saved to: {project_dir}"
            )
            if speak: speak(msg)
            return f"{msg}\n\nOutput:\n{last_output}"

        if attempt == MAX_FIX_ATTEMPTS:
            break

        error_type = _classify_error(last_output)
        if error_type == "dependency_error" and auto_installs < 3:
            installed = _try_auto_install(last_output, project_dir)
            if installed:
                auto_installs += 1
                log("Missing dependency installed, retrying...")
                time.sleep(1)
                continue

        log(f"Fixing errors (type: {error_type})...")
        try:
            updated = _fix_files(
                error_output=last_output,
                project_description=description,
                all_files=files,
                file_codes=file_codes,
                language=language,
                project_dir=project_dir,
                entry_point=entry_point,
            )
            file_codes.update(updated)
            time.sleep(1)
        except RateLimitError:
            msg = "Rate limit reached during fix. Project saved, check it manually in VSCode."
            if speak: speak(msg)
            return msg
        except Exception as e:
            log(f"Fix step failed: {e}")

    msg = (
        f"I couldn't fully fix '{proj_name}' after {MAX_FIX_ATTEMPTS} attempts, sir. "
        f"Project is saved at {project_dir} — open it in VSCode and check manually."
    )
    if speak: speak(msg)
    return f"{msg}\n\nLast error:\n{last_output[:600]}"


def dev_agent(
    parameters: dict,
    response=None,
    player=None,
    session_memory=None,
    speak=None,
) -> str:
    p            = parameters or {}
    description  = p.get("description", "").strip()
    language     = p.get("language", "python").strip()
    project_name = p.get("project_name", "").strip()
    timeout      = int(p.get("timeout", 120))

    if not description:
        return "Please describe the project you want me to build, sir."

    return _build_project(
        description  = description,
        language     = language,
        project_name = project_name,
        timeout      = timeout,
        speak        = speak,
        player       = player,
    )


# ── Tool declaration (auto-discovered by core/action_loader.py) ──────────────
TOOL = {
    "name": "dev_agent",
    "description": "Builds complete multi-file projects and websites from scratch: plans, writes files, installs Python/Node dependencies, opens VSCode, runs builds and fixes errors. Use for full apps, not single-file edits.",
    "parameters": {
        "type": "OBJECT",
        "properties": {
            "description": {
                "type": "STRING",
                "description": "What the project should do"
            },
            "language": {
                "type": "STRING",
                "description": "Language or stack (Python, JavaScript, TypeScript, HTML/CSS/JavaScript; default: Python)"
            },
            "project_name": {
                "type": "STRING",
                "description": "Optional project folder name"
            },
            "timeout": {
                "type": "INTEGER",
                "description": "Maximum project check time in seconds (default: 120)"
            }
        },
        "required": [
            "description"
        ]
    },
    "handler": dev_agent,
}
